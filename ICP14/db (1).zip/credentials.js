module.exports = {
	mongo: {
		connectionString: 'mongodb+srv://mkremer:<password>@fullstackwebdev.ocaw1vp.mongodb.net/USF_CS386?retryWrites=true&w=majority'
	}
};


