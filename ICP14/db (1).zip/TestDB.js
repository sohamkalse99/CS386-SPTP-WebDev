const connectDB = require('./db.js'); //Load mongoose module
connectDB(true); //Create connection
connectDB(false); //Close connection


