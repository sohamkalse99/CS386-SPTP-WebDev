module.exports = {
	mongo: {
		connectionString: 'mongodb+srv://skalse:soham@fullstackwebdev.clfvrdv.mongodb.net/USF_CS386?retryWrites=true&w=majority'
	}
};


